# AmazonChecker
Amazon valid email checker

Usage : python amazon.py
